﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishScript : MonoBehaviour
{
    // Start is called before the first frame update
    [HideInInspector]
    public Vector3 destination;

    public float fishSpeed = 5;

    private UiControl uiController;

    void Start()
    {
        uiController = GameObject.FindGameObjectWithTag("GameController").GetComponent<UiControl>();
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position = Vector3.MoveTowards(transform.position, destination, fishSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        uiController.CaughFish(gameObject.tag);

        Destroy(gameObject);
    }
}
