﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shark_Controller : MonoBehaviour
{
    public float sharkSpeed = 1;

    Vector3 targetPosition;
    private UiControl uiController;

    // Start is called before the first frame update
    void Start()
    {
        uiController = GameObject.FindGameObjectWithTag("GameController").GetComponent<UiControl>();
    }

    // Update is called once per frame
    void Update()
    {
        if(uiController.Lives != 0 && uiController.gameTimer < 300)
        {
            targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            targetPosition.z = transform.position.z;

            this.transform.position = Vector3.MoveTowards(transform.position, targetPosition, sharkSpeed * Time.deltaTime);

            if (Mathf.Abs(targetPosition.x - transform.position.x) > 0.01 || Mathf.Abs(targetPosition.y - transform.position.y) > 0.01)
            {
                transform.rotation = Quaternion.LookRotation(Vector3.forward, transform.position - targetPosition);
            }
        }

    }
}
