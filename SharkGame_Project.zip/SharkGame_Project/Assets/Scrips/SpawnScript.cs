﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnScript : MonoBehaviour
{
    public GameObject spawnLocations;
    public GameObject[] fish;
    public float fishSpawnTime = 1;

    private int spots;
    private float fishTimer;
    private float gameTime;

    // Start is called before the first frame update
    void Start()
    {
        spots = spawnLocations.transform.childCount;
        fishTimer = 0;
        gameTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        gameTime += Time.deltaTime;
        fishSpawnTime = 1 - 0.1f * (gameTime / 60);

        fishTimer += Time.deltaTime;

        if(fishTimer > fishSpawnTime)
        {
            fishTimer = 0;

            int randomSpawn = Random.Range(0, spots);
            int randomFish = Random.Range(0, fish.Length);

            Transform spawnStart = spawnLocations.transform.GetChild(randomSpawn).GetChild(0).transform.transform;
            Vector3 Start = new Vector3(spawnStart.transform.position.x, spawnStart.transform.position.y, -1);

            Transform spawnEnd = spawnLocations.transform.GetChild(randomSpawn).GetChild(1).transform.transform;
            Vector3 End = new Vector3(spawnEnd.transform.position.x, spawnEnd.transform.position.y, -1);

            GameObject newFish = Instantiate(fish[randomFish],Start,spawnStart.rotation);
            newFish.transform.rotation = Quaternion.LookRotation(Vector3.forward, transform.position - spawnEnd.position);
            newFish.GetComponent<FishScript>().destination = End;

            Destroy(newFish, 15.0f);
        }
    }
}
