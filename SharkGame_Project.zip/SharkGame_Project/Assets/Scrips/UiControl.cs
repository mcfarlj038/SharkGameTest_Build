﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UiControl : MonoBehaviour
{
    [HideInInspector]
    public float score = 0;

    [HideInInspector]
    public float Lives = 4;

    public TMP_Text scoreText;
    public TMP_Text livesText;
    public TMP_Text timeLeft;
    public Sprite[] fishImages;
    public Image fish;

    public TMP_Text gameOver;

    private string searchFish;
    [HideInInspector]
    public float gameTimer;

    // Start is called before the first frame update
    void Start()
    {
        scoreText.text = score.ToString();
        searchFish = "Red";
    }

    // Update is called once per frame
    void Update()
    {

        gameTimer += Time.deltaTime;

        scoreText.text = score.ToString();
        livesText.text = Lives.ToString();

        if(Lives == 0)
        {
            gameOver.text = "GAME OVER";
            Time.timeScale = 0;
        }
        if(gameTimer >= 300)
        {
            gameOver.text = "TIMES UP!";
            Time.timeScale = 0;
        }

        string timeText;
        int minutes = (300 - (int)gameTimer) / 60;
        int second = 60 - (int)(gameTimer % 60);

        if(second == 60)
        {
            second = 0;
        }

        if(second < 10)
        {
            timeText = minutes.ToString() + ":0" + second.ToString();
        } else
        {
            timeText = minutes.ToString() + ":" + second.ToString();
        }
        timeLeft.text = timeText;
    }

    public void CaughFish(string fishColor)
    {
        if(searchFish == fishColor)
        {
            score += 10;
            NewSearch();
        }else
        {
            Lives--;
        }
    }

    private void NewSearch()
    {
        int randomSearch = Random.Range(0, 4);

        switch(randomSearch)
        {
            case 0:
                searchFish = "Red";
                break;
            case 1:
                searchFish = "Green";
                break;
            case 2:
                searchFish = "Blue";
                break;
            case 3:
                searchFish = "Teal";
                break;
            default:
                break;
        }

        fish.sprite = fishImages[randomSearch];
    }
}
